﻿using System;
using System.Collections.Generic;
using System.Text;
using VendorMachine.Application.Interfaces;

namespace VendorMachine
{
    public class ProductView
    {
        public ProductView(IProductService productService)
        {

        }
    }
}
